// @refresh reset
import "@mantine/core/styles.css";
import "@mantine/notifications/styles.css";
import "./App.css";
import "./index.css";

import { useInView } from "react-intersection-observer";
import { Notifications } from "@mantine/notifications";
import { Environment, PerformanceMonitor, Stats } from "@react-three/drei";
import * as THREE from "three";
import { Canvas, useThree, useFrame } from "@react-three/fiber";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  DEFAULT_VIEWPORT_METRICS,
  ViewportLayoutProvider,
} from "./ViewportLayoutContext";
import { ViewerMutable } from "./ViewerContext";
import {
  Anchor,
  Box,
  Divider,
  Image,
  MantineProvider,
  Modal,
  Tooltip,
  createTheme,
  useMantineColorScheme,
  useMantineTheme,
} from "@mantine/core";
import { useDisclosure } from "@mantine/hooks";

// Local imports.
import { SynchronizedCameraControls } from "./CameraControls";
import { SceneNodeThreeObject } from "./SceneTree";
import { shallowArrayEqual } from "./utils/shallowArrayEqual";
import { ViewerContext, ViewerContextContents } from "./ViewerContext";
import ControlPanel from "./ControlPanel/ControlPanel";
import { useGuiState } from "./ControlPanel/GuiState";
import { searchParamKey } from "./SearchParamsUtils";
import { WebsocketMessageProducer } from "./WebsocketInterface";
import { Titlebar } from "./Titlebar";
import { ViserModal } from "./Modal";
import { useSceneTreeState } from "./SceneTreeState";
import { useEnvironmentState } from "./EnvironmentState";
import { useDevSettingsStore } from "./DevSettingsStore";
import { useThrottledMessageSender } from "./WebsocketUtils";
import { rayToViserCoords } from "./WorldTransformUtils";
import { theme } from "./AppTheme";
import { FrameSynchronizedMessageHandler } from "./MessageHandler";
import { PlaybackFromFile } from "./FilePlayback";
import { SplatRenderContext } from "./Splatting/GaussianSplats";
import { BrowserWarning } from "./BrowserWarning";
import { MacWindowWrapper } from "./MacWindowWrapper";
import { CsmDirectionalLight } from "./CsmDirectionalLight";
import { VISER_VERSION, GITHUB_CONTRIBUTORS, Contributor } from "./VersionInfo";
import {
  COLUMN_GAP_PX,
  DEFAULT_CANVAS_RATIO,
  DEFAULT_FIRST_COLUMN_WIDTH_PX,
  FIRST_COLUMN_MIN_RATIO,
  JOINT_COLUMN_MIN_WIDTH_PX,
  MIN_CANVAS_RATIO,
  DEFAULT_JOINT_COLUMN_COUNT,
} from "./layoutConstants";
import { BatchedLabelManager } from "./BatchedLabelManager";

const DEFAULT_ROOT_SCALE = 1;

// ======= Utility functions =======

/** Turn a click event into a normalized device coordinate (NDC) vector.
 * Normalizes click coordinates to be between -1 and 1, with (0, 0) being the center of the screen.
 *
 * Returns null if input is not valid.
 */
function ndcFromPointerXy(
  viewer: ViewerContextContents,
  xy: [number, number],
): THREE.Vector2 | null {
  const metrics = viewer.mutable.current.viewportMetrics;
  if (metrics.width <= 0 || metrics.height <= 0) {
    return null;
  }
  const mouseVector = new THREE.Vector2();
  mouseVector.x = 2 * ((xy[0] + 0.5) / metrics.width) - 1;
  mouseVector.y = 1 - 2 * ((xy[1] + 0.5) / metrics.height);
  return mouseVector.x < 1 &&
    mouseVector.x > -1 &&
    mouseVector.y < 1 &&
    mouseVector.y > -1
    ? mouseVector
    : null;
}

/** Turn a click event to normalized OpenCV coordinate (NDC) vector.
 * Normalizes click coordinates to be between (0, 0) as upper-left corner,
 * and (1, 1) as lower-right corner, with (0.5, 0.5) being the center of the screen.
 * Uses offsetX/Y, and clientWidth/Height to get the coordinates.
 */
function opencvXyFromPointerXy(
  viewer: ViewerContextContents,
  xy: [number, number],
): THREE.Vector2 {
  const metrics = viewer.mutable.current.viewportMetrics;
  const mouseVector = new THREE.Vector2();
  if (metrics.width <= 0 || metrics.height <= 0) {
    mouseVector.set(0, 0);
    return mouseVector;
  }
  mouseVector.x = (xy[0] + 0.5) / metrics.width;
  mouseVector.y = (xy[1] + 0.5) / metrics.height;
  return mouseVector;
}

/** Gets default WebSocket server URL based on current window location. */
const getDefaultServerFromUrl = (): string => {
  let server = window.location.href;
  server = server.replace("http://", "ws://");
  server = server.replace("https://", "wss://");
  server = server.split("?")[0];
  if (server.endsWith("/")) server = server.slice(0, -1);
  return server;
};

/** Disables rendering when component is not in view. */
const DisableRender = (): null => useFrame(() => null, 1000);

// ======= Main component tree =======

/**
 * Root application component - handles dummy window wrapper if needed.
 */
export function Root() {
  useEffect(() => {
    const rootElement = document.getElementById("root");
    if (!rootElement) {
      return;
    }

    const previousTransform = rootElement.style.transform;
    const previousTransformOrigin = rootElement.style.transformOrigin;
    const previousWidth = rootElement.style.width;

    const scale = DEFAULT_ROOT_SCALE;
    const expandedWidthPercent = `${(1 / scale) * 100}%`;

    rootElement.style.transform = `scale(${scale})`;
    rootElement.style.transformOrigin = "top left";
    if (!previousWidth || previousWidth === "") {
      rootElement.style.width = expandedWidthPercent;
    } else {
      rootElement.style.width = expandedWidthPercent;
    }

    return () => {
      rootElement.style.transform = previousTransform;
      rootElement.style.transformOrigin = previousTransformOrigin;
      rootElement.style.width = previousWidth;
    };
  }, []);

  const searchParams = new URLSearchParams(window.location.search);
  const dummyWindowParam = searchParams.get("dummyWindowDimensions");
  const dummyWindowTitle =
    searchParams.get("dummyWindowTitle") ?? "localhost:8080";

  const content = (
    <div
      style={{
        width: "100%",
        height: "100%",
        position: "relative",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <ViewerRoot />
    </div>
  );

  // If dummy window dimensions are specified, wrap content in MacWindowWrapper.
  if (!dummyWindowParam) return content;

  // Handle "fill" flag to make window full size
  if (dummyWindowParam === "fill") {
    return (
      <MacWindowWrapper
        title={dummyWindowTitle}
        width={window.innerWidth}
        height={window.innerHeight}
        fill={true}
      >
        {content}
      </MacWindowWrapper>
    );
  }

  const [width, height] = dummyWindowParam.split("x").map(Number);
  if (isNaN(width) || isNaN(height)) return content;

  return (
    <MacWindowWrapper title={dummyWindowTitle} width={width} height={height}>
      {content}
    </MacWindowWrapper>
  );
}

/**
 * Main viewer context provider component.
 */
function ViewerRoot() {
  // Server configuration and URL parameters.
  const servers = new URLSearchParams(window.location.search).getAll(
    searchParamKey,
  );
  const initialServer =
    servers.length >= 1 ? servers[0] : getDefaultServerFromUrl();

  const searchParams = new URLSearchParams(window.location.search);
  const playbackPath = searchParams.get("playbackPath");
  const darkMode = searchParams.get("darkMode") !== null;

  // Create a message source string.
  const messageSource = playbackPath === null ? "websocket" : "file_playback";

  // Create a single ref with all mutable state.
  const nodeRefFromName = {};
  const mutable = React.useRef<ViewerMutable>({
    // Function references with default implementations.
    sendMessage:
      playbackPath == null
        ? (message: any) =>
            console.log(
              `Tried to send ${message.type} but websocket is not connected!`,
            )
        : () => null,
    sendCamera: null,
    resetCameraView: null,

    // DOM/Three.js references.
    canvas: null,
    canvas2d: null,
    scene: null,
    camera: null,
    backgroundMaterial: null,
    cameraControl: null,
    viewportMetrics: DEFAULT_VIEWPORT_METRICS,

    // Scene management.
    nodeRefFromName,

    // Message and rendering state.
    messageQueue: [],
    getRenderRequestState: "ready",
    getRenderRequest: null,

    // Interaction state.
    scenePointerInfo: {
      enabled: false,
      dragStart: [0, 0],
      dragEnd: [0, 0],
      isDragging: false,
    },

    // Skinned mesh state.
    skinnedMeshState: {},

    // Global hover state tracking.
    hoveredElementsCount: 0,
  });

  // Create the scene tree state and extract store and actions.
  const sceneTreeState = useSceneTreeState(mutable.current.nodeRefFromName);

  // Create the environment state and extract store and actions.
  const environmentState = useEnvironmentState();

  // Create the dev settings store.
  const devSettingsStore = useDevSettingsStore();

  // Create the context value with hooks and single ref.
  const viewer: ViewerContextContents = {
    messageSource,
    useSceneTree: sceneTreeState.store,
    sceneTreeActions: sceneTreeState.actions,
    useEnvironment: environmentState,
    useGui: useGuiState(initialServer),
    useDevSettings: devSettingsStore,
    mutable,
  };

  // Apply URL dark mode setting if provided.
  if (darkMode) viewer.useGui.getState().theme.dark_mode = darkMode;

  return (
    <ViewerContext.Provider value={viewer}>
      <ViewerContents>
        {messageSource === "websocket" && <WebsocketMessageProducer />}
        {messageSource === "file_playback" && (
          <PlaybackFromFile fileUrl={playbackPath!} />
        )}
      </ViewerContents>
    </ViewerContext.Provider>
  );
}

/**
 * Main content wrapper with theme and layout.
 */
function ViewerContents({ children }: { children: React.ReactNode }) {
  const viewer = React.useContext(ViewerContext)!;
  const darkMode = viewer.useGui((state) => state.theme.dark_mode);
  const colors = viewer.useGui((state) => state.theme.colors);
  const controlLayout = viewer.useGui((state) => state.theme.control_layout);
  const showLogo = viewer.useGui((state) => state.theme.show_logo);
  const showStats = viewer.useDevSettings((state) => state.showStats);
  const { messageSource } = viewer;

  // Create Mantine theme with custom colors if provided.
  const mantineTheme = useMemo(
    () =>
      createTheme({
        ...theme,
        ...(colors === null
          ? {}
          : { colors: { custom: colors }, primaryColor: "custom" }),
      }),
    [colors],
  );
  const canvases = useMemo(
    () => (
      <ViewerCanvas>
        <FrameSynchronizedMessageHandler />
      </ViewerCanvas>
    ),
    [],
  );
  const defaultViewportWidth = React.useMemo(
    () => (typeof window !== "undefined" ? window.innerWidth : 1280),
    [],
  );
  const isFloatingLayout = controlLayout === "floating";
  const [viewportWidth, setViewportWidth] = React.useState(() =>
    typeof window !== "undefined"
      ? window.innerWidth
      : defaultViewportWidth,
  );
  React.useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }
    const onResize = () => {
      setViewportWidth(window.innerWidth);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  const clampedViewportWidth = Number.isFinite(viewportWidth)
    ? Math.max(viewportWidth, 1)
    : 1280;

  const layoutMetrics = React.useMemo(() => {
    if (clampedViewportWidth <= 0) {
      return {
        panelWidthPx: 0,
        canvasWidthPx: 0,
        panelRatio: 0,
      };
    }

    const columnCount = DEFAULT_JOINT_COLUMN_COUNT + 1;
    const jointCount = Math.max(columnCount - 1, 0);
    const gapTotal = COLUMN_GAP_PX * Math.max(columnCount - 1, 0);
    const minPanelWidth =
      DEFAULT_FIRST_COLUMN_WIDTH_PX * FIRST_COLUMN_MIN_RATIO +
      JOINT_COLUMN_MIN_WIDTH_PX * jointCount +
      gapTotal;
    const minCanvasWidth = MIN_CANVAS_RATIO * clampedViewportWidth;
    const maxPanelWidth = Math.max(clampedViewportWidth - minCanvasWidth, 0);

    let canvasWidthPx = DEFAULT_CANVAS_RATIO * clampedViewportWidth;
    canvasWidthPx = Math.min(
      Math.max(canvasWidthPx, minCanvasWidth),
      clampedViewportWidth,
    );

    let panelWidthPx = Math.max(clampedViewportWidth - canvasWidthPx, 0);

    if (panelWidthPx < minPanelWidth) {
      const needed = minPanelWidth - panelWidthPx;
      const canvasShrink = Math.min(
        needed,
        Math.max(canvasWidthPx - minCanvasWidth, 0),
      );
      if (canvasShrink > 0) {
        canvasWidthPx -= canvasShrink;
        panelWidthPx += canvasShrink;
      }
      panelWidthPx = Math.max(clampedViewportWidth - canvasWidthPx, 0);
    }

    panelWidthPx = Math.min(panelWidthPx, maxPanelWidth);
    if (panelWidthPx < 0) {
      panelWidthPx = 0;
    }

    const finalCanvasWidthPx = Math.max(
      clampedViewportWidth - panelWidthPx,
      minCanvasWidth,
    );
    const finalPanelWidthPx = Math.max(
      Math.min(clampedViewportWidth - finalCanvasWidthPx, maxPanelWidth),
      0,
    );

    const panelRatio =
      clampedViewportWidth > 0
        ? Math.min(
            Math.max(finalPanelWidthPx / clampedViewportWidth, 0),
            1,
          )
        : 0;

    return {
      panelWidthPx: finalPanelWidthPx,
      canvasWidthPx: finalCanvasWidthPx,
      panelRatio,
    };
  }, [clampedViewportWidth]);

  const panelWidthPx = layoutMetrics.panelWidthPx;
  const canvasWidthPx = layoutMetrics.canvasWidthPx;
  const forcedPanelRatio = layoutMetrics.panelRatio;

  const panelWidthPxString = `${Math.round(panelWidthPx)}px`;
  const canvasWidthPxString = `${Math.round(canvasWidthPx)}px`;
  return (
    <>
      <MantineProvider
        theme={mantineTheme}
        defaultColorScheme={darkMode ? "dark" : "light"}
        colorSchemeManager={{
          // Mock external color scheme manager. This prevents multiple Viser
          // instances from affecting each others' color schemes.
          get: (defaultValue) => defaultValue,
          set: () => null,
          subscribe: () => null,
          unsubscribe: () => null,
          clear: () => null,
        }}
      >
        {children}
        <ColorSchemeSetter darkMode={darkMode} />
        <NotificationsPanel />
        <BrowserWarning />
        <ViserModal />
        {/* App layout */}
        <Box
          style={{
            width: "100%",
            height: "100%",
            display: "flex",
            position: "relative",
            flexDirection: "column",
          }}
        >
          <Titlebar />
          <Box
            style={
              isFloatingLayout
                ? {
                    width: "100%",
                    position: "relative",
                    flexGrow: 1,
                    overflow: "hidden",
                    display: "flex",
                  }
                : {
                    width: "100%",
                    position: "relative",
                    flexGrow: 1,
                    overflow: "hidden",
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "stretch",
                  }
            }
          >
            <Box
              style={(theme) => ({
                backgroundColor: darkMode ? theme.colors.dark[9] : "#fff",
                overflow: "hidden",
                height: "100%",
                position: "relative",
                display: "flex",
                flexDirection: "column",
                ...(isFloatingLayout
                  ? { flexGrow: 1, minWidth: 0 }
                  : {
                      flex: `0 0 ${canvasWidthPxString}`,
                      width: canvasWidthPxString,
                      minWidth: canvasWidthPxString,
                      maxWidth: canvasWidthPxString,
                    }),
              })}
            >
              {canvases}
              {showLogo && messageSource === "websocket" && <ViserLogo />}
            </Box>
            {messageSource === "websocket" && (
              isFloatingLayout ? (
                <ControlPanel
                  control_layout={controlLayout}
                  minCanvasRatio={MIN_CANVAS_RATIO}
                />
              ) : (
                <Box
                  style={{
                    flex: `0 0 ${panelWidthPxString}`,
                    width: panelWidthPxString,
                    minWidth: panelWidthPxString,
                    maxWidth: panelWidthPxString,
                    height: "100%",
                    display: "flex",
                    justifyContent: "stretch",
                  }}
                >
                  <ControlPanel
                    control_layout={controlLayout}
                    minCanvasRatio={MIN_CANVAS_RATIO}
                    forcedPanelRatio={forcedPanelRatio}
                  />
                </Box>
              )
            )}
          </Box>
        </Box>
        {showStats && <Stats className="stats-panel" />}
      </MantineProvider>
    </>
  );
}

function ColorSchemeSetter(props: { darkMode: boolean }) {
  const colorScheme = useMantineColorScheme();
  // Update data attribute for color scheme.
  useEffect(() => {
    colorScheme.setColorScheme(props.darkMode ? "dark" : "light");
  }, [props.darkMode]);
  return null;
}

/**
 * Notifications panel with fixed styling.
 */
function NotificationsPanel() {
  return (
    <Notifications
      position="top-left"
      limit={10}
      containerWidth="20em"
      withinPortal={false}
      styles={{
        root: {
          boxShadow: "0.1em 0 1em 0 rgba(0,0,0,0.1) !important",
          position: "absolute",
          top: "1em",
          left: "1em",
          pointerEvents: "none",
        },
        notification: {
          pointerEvents: "all",
        },
      }}
    />
  );
}

/**
 * Main 3D canvas component.
 */
function ViewerCanvas({ children }: { children: React.ReactNode }) {
  const viewer = React.useContext(ViewerContext)!;
  const sendClickThrottled = useThrottledMessageSender(20).send;
  const theme = useMantineTheme();
  const { ref: inViewRef, inView } = useInView();
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [containerElement, setContainerElement] = useState<
    HTMLDivElement | null
  >(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const assignContainerRef = React.useCallback(
    (node: HTMLDivElement | null) => {
      containerRef.current = node;
      setContainerElement(node);
      inViewRef(node);
    },
    [inViewRef],
  );

  // Memoize camera controls to prevent unnecessary re-creation.
  const memoizedCameraControls = useMemo(
    () => <SynchronizedCameraControls />,
    [],
  );

  useEffect(() => {
    const resizeObserver = new ResizeObserver((entries) => {
      const { width, height } = entries[0].contentRect;
      const overlayCanvas = overlayCanvasRef.current;
      if (!overlayCanvas) return;
      overlayCanvas.width = width;
      overlayCanvas.height = height;
    });

    if (containerElement) {
      resizeObserver.observe(containerElement);
    }

    return () => {
      resizeObserver.disconnect();
    };
  }, [containerElement]);

  // Handle pointer down event. I don't think we need useCallback here, since
  // remounts should be very rare.
  const handlePointerDown = (e: React.PointerEvent) => {
    const { mutable } = viewer;
    const pointerInfo = mutable.current.scenePointerInfo;
    if (pointerInfo.enabled === false) return;

    const metrics = mutable.current.viewportMetrics;
    if (metrics.width <= 0 || metrics.height <= 0) {
      return;
    }
    const pointerX = e.clientX - metrics.left;
    const pointerY = e.clientY - metrics.top;
    pointerInfo.dragStart = [pointerX, pointerY];
    pointerInfo.dragEnd = pointerInfo.dragStart;

    if (ndcFromPointerXy(viewer, pointerInfo.dragEnd) === null) return;
    if (pointerInfo.isDragging) return;

    pointerInfo.isDragging = true;
    const cameraControls = mutable.current.cameraControl;
    if (cameraControls) {
      cameraControls.enabled = false;
    }

    const ctx = mutable.current.canvas2d!.getContext("2d")!;
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  };

  // Handle pointer move event.
  const handlePointerMove = (e: React.PointerEvent) => {
    const { mutable } = viewer;
    const pointerInfo = mutable.current.scenePointerInfo;
    if (pointerInfo.enabled === false || !pointerInfo.isDragging) return;

    const metrics = mutable.current.viewportMetrics;
    if (metrics.width <= 0 || metrics.height <= 0) {
      return;
    }
    const pointerXy: [number, number] = [
      e.clientX - metrics.left,
      e.clientY - metrics.top,
    ];

    if (ndcFromPointerXy(viewer, pointerXy) === null) return;
    pointerInfo.dragEnd = pointerXy;

    // Check if pointer moved enough to be considered a drag.
    if (
      Math.abs(pointerInfo.dragEnd[0] - pointerInfo.dragStart[0]) <= 3 &&
      Math.abs(pointerInfo.dragEnd[1] - pointerInfo.dragStart[1]) <= 3
    )
      return;

    // Draw selection rectangle if in rect-select mode.
    if (pointerInfo.enabled === "rect-select") {
      const ctx = mutable.current.canvas2d!.getContext("2d")!;
      ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      ctx.beginPath();
      ctx.fillStyle = theme.primaryColor;
      ctx.strokeStyle = "blue";
      ctx.globalAlpha = 0.2;
      ctx.fillRect(
        pointerInfo.dragStart[0],
        pointerInfo.dragStart[1],
        pointerInfo.dragEnd[0] - pointerInfo.dragStart[0],
        pointerInfo.dragEnd[1] - pointerInfo.dragStart[1],
      );
      ctx.globalAlpha = 1.0;
      ctx.stroke();
    }
  };

  // Handle pointer up event.
  const handlePointerUp = () => {
    const { mutable } = viewer;
    const pointerInfo = mutable.current.scenePointerInfo;

    // Re-enable camera controls.
    const cameraControls = mutable.current.cameraControl;
    if (cameraControls) {
      cameraControls.enabled = true;
    }
    if (pointerInfo.enabled === false || !pointerInfo.isDragging) return;

    const ctx = mutable.current.canvas2d!.getContext("2d")!;
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    // Handle click or rect-select based on mode.
    if (pointerInfo.enabled === "click") {
      sendClickMessage(viewer, pointerInfo.dragEnd, sendClickThrottled);
    } else if (pointerInfo.enabled === "rect-select") {
      sendRectSelectMessage(viewer, pointerInfo, sendClickThrottled);
    }

    pointerInfo.isDragging = false;
  };

  const fixedDpr = viewer.useDevSettings((state) => state.fixedDpr);
  const sceneContents = React.useMemo(
    () => (
      <>
        <BackgroundImage />
        <SceneContextSetter />
        {memoizedCameraControls}
        <SplatRenderContext>
          <AdaptiveDpr />
          {children}
          <BatchedLabelManager>
            <SceneNodeThreeObject name="" />
          </BatchedLabelManager>
        </SplatRenderContext>
        <DefaultLights />
      </>
    ),
    [children, memoizedCameraControls],
  );
  return (
    <ViewportLayoutProvider targetRef={containerRef}>
      <div
        ref={assignContainerRef}
        style={{
          position: "relative",
          zIndex: 0,
          width: "100%",
          height: "100%",
        }}
      >
        <canvas
          ref={(el) => {
            overlayCanvasRef.current = el;
            viewer.mutable.current.canvas2d = el;
          }}
          style={{
            position: "absolute",
            zIndex: 1,
            width: "100%",
            height: "100%",
            pointerEvents: "none",
          }}
        />
        <Canvas
          camera={{ position: [-3.0, 3.0, -3.0], near: 0.01, far: 1000.0 }}
          gl={{ preserveDrawingBuffer: true }}
          style={{ width: "100%", height: "100%" }}
          ref={(el) => (viewer.mutable.current.canvas = el)}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          shadows
          dpr={fixedDpr ?? undefined}
        >
          {!inView && <DisableRender />}
          {sceneContents}
        </Canvas>
      </div>
    </ViewportLayoutProvider>
  );
}

// ======= Helper functions for pointer events. =======

/**
 * Send a click message based on the pointer position.
 */
function sendClickMessage(
  viewer: ViewerContextContents,
  pointerPos: [number, number],
  sendClickThrottled: (message: any) => void,
) {
  const raycaster = new THREE.Raycaster();
  const mouseVector = ndcFromPointerXy(viewer, pointerPos);
  if (mouseVector === null) return;

  raycaster.setFromCamera(mouseVector, viewer.mutable.current.camera!);
  const ray = rayToViserCoords(viewer, raycaster.ray);
  const mouseVectorOpenCV = opencvXyFromPointerXy(viewer, pointerPos);

  sendClickThrottled({
    type: "ScenePointerMessage",
    event_type: "click",
    ray_origin: [ray.origin.x, ray.origin.y, ray.origin.z],
    ray_direction: [ray.direction.x, ray.direction.y, ray.direction.z],
    screen_pos: [[mouseVectorOpenCV.x, mouseVectorOpenCV.y]],
  });
}

/**
 * Send a rectangle selection message based on drag start/end positions.
 */
function sendRectSelectMessage(
  viewer: ViewerContextContents,
  pointerInfo: { dragStart: [number, number]; dragEnd: [number, number] },
  sendClickThrottled: (message: any) => void,
) {
  const firstMouseVector = opencvXyFromPointerXy(viewer, pointerInfo.dragStart);
  const lastMouseVector = opencvXyFromPointerXy(viewer, pointerInfo.dragEnd);

  const x_min = Math.min(firstMouseVector.x, lastMouseVector.x);
  const x_max = Math.max(firstMouseVector.x, lastMouseVector.x);
  const y_min = Math.min(firstMouseVector.y, lastMouseVector.y);
  const y_max = Math.max(firstMouseVector.y, lastMouseVector.y);

  sendClickThrottled({
    type: "ScenePointerMessage",
    event_type: "rect-select",
    ray_origin: null,
    ray_direction: null,
    screen_pos: [
      [x_min, y_min],
      [x_max, y_max],
    ],
  });
}

/**
 * DefaultLights component - handles environment map and lights.
 */
function DefaultLights() {
  const viewer = React.useContext(ViewerContext)!;
  const enableDefaultLights = viewer.useEnvironment(
    (state) => state.enableDefaultLights,
  );
  const enableDefaultLightsShadows = viewer.useEnvironment(
    (state) => state.enableDefaultLightsShadows,
  );
  const environmentMap = viewer.useEnvironment((state) => state.environmentMap);

  // Get world rotation directly from scene tree state.
  const worldRotation = viewer.useSceneTree(
    (state) => state[""]?.wxyz ?? [1, 0, 0, 0],
    shallowArrayEqual,
  );

  // Calculate environment map.
  const envMapNode = useMemo(() => {
    if (environmentMap.hdri === null) return null;

    // HDRI presets mapping.
    const presetsObj = {
      apartment: "lebombo_1k.hdr",
      city: "potsdamer_platz_1k.hdr",
      dawn: "kiara_1_dawn_1k.hdr",
      forest: "forest_slope_1k.hdr",
      lobby: "st_fagans_interior_1k.hdr",
      night: "dikhololo_night_1k.hdr",
      park: "rooitou_park_1k.hdr",
      studio: "studio_small_03_1k.hdr",
      sunset: "venice_sunset_1k.hdr",
      warehouse: "empty_warehouse_01_1k.hdr",
    };

    // Calculate quaternions for world transformation.
    const Rquat_threeworld_world = new THREE.Quaternion(
      worldRotation[1],
      worldRotation[2],
      worldRotation[3],
      worldRotation[0],
    );
    const Rquat_world_threeworld = Rquat_threeworld_world.clone().invert();

    // Calculate background rotation.
    const backgroundRotation = new THREE.Euler().setFromQuaternion(
      new THREE.Quaternion(
        environmentMap.background_wxyz[1],
        environmentMap.background_wxyz[2],
        environmentMap.background_wxyz[3],
        environmentMap.background_wxyz[0],
      )
        .premultiply(Rquat_threeworld_world)
        .multiply(Rquat_world_threeworld),
    );

    // Calculate environment rotation.
    const environmentRotation = new THREE.Euler().setFromQuaternion(
      new THREE.Quaternion(
        environmentMap.environment_wxyz[1],
        environmentMap.environment_wxyz[2],
        environmentMap.environment_wxyz[3],
        environmentMap.environment_wxyz[0],
      )
        .premultiply(Rquat_threeworld_world)
        .multiply(Rquat_world_threeworld),
    );

    return (
      <Environment
        files={`hdri/${presetsObj[environmentMap.hdri]}`}
        background={environmentMap.background}
        backgroundBlurriness={environmentMap.background_blurriness}
        backgroundIntensity={environmentMap.background_intensity}
        backgroundRotation={backgroundRotation}
        environmentIntensity={environmentMap.environment_intensity}
        environmentRotation={environmentRotation}
      />
    );
  }, [environmentMap, worldRotation]);

  // Return environment map only if lights are disabled.
  if (!enableDefaultLights) return envMapNode;

  // Return lights and environment map.
  return (
    <>
      <CsmDirectionalLight
        lightIntensity={3.0}
        position={[-0.2, 1.0, -0.2]}
        cascades={3}
        castShadow={enableDefaultLightsShadows}
      />
      <CsmDirectionalLight
        lightIntensity={0.4}
        position={[0, -1, 0]}
        castShadow={false}
      />
      {envMapNode}
    </>
  );
}

/**
 * Adaptive DPR component for performance optimization.
 */
function AdaptiveDpr() {
  const viewer = React.useContext(ViewerContext)!;
  const setDpr = useThree((state) => state.setDpr);
  const fixedDpr = viewer.useDevSettings((state) => state.fixedDpr);

  return fixedDpr !== null ? null : (
    <PerformanceMonitor
      factor={1.0}
      step={0.2}
      bounds={(refreshrate) => {
        const max = Math.min(refreshrate * 0.75, 85);
        const min = Math.max(max * 0.5, 38);
        return [min, max];
      }}
      onChange={({ factor, fps, refreshrate }) => {
        const dpr = window.devicePixelRatio * (0.2 + 0.8 * factor);
        console.log(
          `[Performance] Setting DPR to ${dpr}; FPS=${fps}/${refreshrate}`,
        );
        setDpr(dpr);
      }}
    />
  );
}

/**
 * Background image component with depth support.
 */
function BackgroundImage() {
  // Shader for background image with depth.
  const shaders = useMemo(
    () => ({
      vert: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
    `,
      frag: `
    #include <packing>
    precision highp float;
    precision highp int;

    varying vec2 vUv;
    uniform sampler2D colorMap;
    uniform sampler2D depthMap;
    uniform float cameraNear;
    uniform float cameraFar;
    uniform bool enabled;
    uniform bool hasDepth;

    float readDepth(sampler2D depthMap, vec2 coord) {
      vec4 rgbPacked = texture(depthMap, coord);
      // Important: BGR format, because buffer was encoded using OpenCV.
      float depth = rgbPacked.b * 0.00255 + rgbPacked.g * 0.6528 + rgbPacked.r * 167.1168;
      return depth;
    }

    void main() {
      if (!enabled) {
        discard;
      }
      vec4 color = texture(colorMap, vUv);
      gl_FragColor = vec4(color.rgb, 1.0);

      float bufDepth;
      if(hasDepth){
        float depth = readDepth(depthMap, vUv);
        bufDepth = viewZToPerspectiveDepth(-depth, cameraNear, cameraFar);
      } else {
        bufDepth = 1.0;
      }
      gl_FragDepth = bufDepth;
    }
    `,
    }),
    [],
  );

  // Create material.
  const backgroundMaterial = useMemo(
    () =>
      new THREE.ShaderMaterial({
        fragmentShader: shaders.frag,
        vertexShader: shaders.vert,
        uniforms: {
          enabled: { value: false },
          depthMap: { value: null },
          colorMap: { value: null },
          cameraNear: { value: null },
          cameraFar: { value: null },
          hasDepth: { value: false },
        },
      }),
    [shaders],
  );

  // Store material in viewer context.
  const { mutable } = React.useContext(ViewerContext)!;
  mutable.current.backgroundMaterial = backgroundMaterial;
  const backgroundMesh = React.useRef<THREE.Mesh>(null);

  // Update position and rotation in render loop.
  useFrame(({ camera }) => {
    if (!(camera instanceof THREE.PerspectiveCamera)) {
      console.error(
        "Camera is not a perspective camera, cannot render background image.",
      );
      return;
    }

    const mesh = backgroundMesh.current!;

    // Position behind camera.
    const lookdir = camera.getWorldDirection(new THREE.Vector3());
    mesh.position.copy(camera.position).addScaledVector(lookdir, 1.0);
    mesh.quaternion.copy(camera.quaternion);

    // Size based on camera parameters.
    const f = camera.getFocalLength();
    mesh.scale.set(camera.getFilmWidth() / f, camera.getFilmHeight() / f, 1.0);

    // Update shader uniforms.
    backgroundMaterial.uniforms.cameraNear.value = camera.near;
    backgroundMaterial.uniforms.cameraFar.value = camera.far;
  });

  return (
    <mesh ref={backgroundMesh} material={backgroundMaterial}>
      <planeGeometry attach="geometry" args={[1, 1]} />
    </mesh>
  );
}

/**
 * Helper component to sync scene and camera state.
 */
function SceneContextSetter() {
  const { mutable } = React.useContext(ViewerContext)!;
  mutable.current.scene = useThree((state) => state.scene);
  mutable.current.camera = useThree(
    (state) => state.camera as THREE.PerspectiveCamera,
  );
  return null;
}

/**
 * Viser logo with about modal.
 */
function ViserLogo() {
  const [aboutModalOpened, { open: openAbout, close: closeAbout }] =
    useDisclosure(false);

  return (
    <>
      <Tooltip label={`Viser ${VISER_VERSION}`}>
        <Box
          style={{
            position: "absolute",
            bottom: "1em",
            left: "1em",
            cursor: "pointer",
          }}
          component="a"
          onClick={openAbout}
          title="About Viser"
        >
          <Image src="./logo.svg" style={{ width: "2.5em", height: "auto" }} />
        </Box>
      </Tooltip>
      <Modal
        opened={aboutModalOpened}
        onClose={closeAbout}
        withCloseButton={false}
        size="xl"
        style={{ textAlign: "center" }}
        trapFocus={false}
      >
        <Box pt="lg" pb="xs">
          Viser is a 3D visualization toolkit developed at UC Berkeley.
        </Box>
        <Box pb="lg">
          <Anchor
            href="https://viser.studio/main"
            target="_blank"
            style={{ fontWeight: "600" }}
          >
            Documentation
          </Anchor>
          &nbsp;&nbsp;&bull;&nbsp;&nbsp;
          <Anchor
            href="https://github.com/nerfstudio-project/viser"
            target="_blank"
            style={{ fontWeight: "600" }}
          >
            GitHub
          </Anchor>
        </Box>
        <Divider />
        <Box
          style={{
            textAlign: "left",
            maxHeight: "120px",
            overflowY: "auto",
            lineHeight: "1",
            fontSize: "0.8rem",
            opacity: "0.75",
          }}
          px="md"
          pt="sm"
        >
          Thanks to our contributors!{" "}
          {GITHUB_CONTRIBUTORS.map(
            (contributor: Contributor, index: number) => (
              <span key={contributor.login}>
                <Anchor
                  href={contributor.html_url}
                  target="_blank"
                  style={{ textDecoration: "none", fontSize: "0.75rem" }}
                >
                  {contributor.login}
                </Anchor>
                {index < GITHUB_CONTRIBUTORS.length - 1 && ", "}
              </span>
            ),
          )}
        </Box>
      </Modal>
    </>
  );
}
